# Veil Studio requirements — prepared by Codex

1. Users can import JPG, PNG and WEBP images, including by drag/drop and paste.
2. Every face mask can be moved, resized, restyled and deleted; manual masks work without a model.
3. Original mode exports at source resolution; poster mode exports at the displayed ratio without editor selection outlines.
4. Undo/redo restores the composition; saved JSON projects restore the image, masks and settings.
5. Automatic detection loads only bundled assets and gives useful feedback when no face is found.
6. Third-party resources and existing Baiquan inspiration are disclosed.

Status: initial implementation by Codex. Kiro implementation/review has not occurred.
