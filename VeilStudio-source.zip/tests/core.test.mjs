import test from 'node:test';
import assert from 'node:assert/strict';
import {layout,sourcePoint,hitMask,initialConfig,validateProject,fromLandmarks} from '../dist/core.mjs';
test('source coordinates survive every poster layout and original mode',()=>{
 for(const format of ['original','poster'])for(const ratio of ['4:5','9:16','1:1'])for(const image of [{width:4000,height:700},{width:800,height:2400}]){
  const l=layout({...initialConfig(),format,ratio},image);
  assert.ok(l.photo.x>=0&&l.photo.y>=0);
  assert.ok(l.photo.x+l.photo.w<=l.w+.001&&l.photo.y+l.photo.h<=l.h+.001);
  for(const p of [{x:0,y:0},{x:1,y:1},{x:.4,y:.7}]){const q=sourcePoint({x:l.photo.x+p.x*l.photo.w,y:l.photo.y+p.y*l.photo.h},l.photo);assert.ok(Math.abs(q.x-p.x)<1e-9&&Math.abs(q.y-p.y)<1e-9);}
 }
});
test('hit testing chooses topmost mask and follows resized mask bounds',()=>{const masks=[{x:.4,y:.5,rx:.1,ry:.15,scale:1},{x:.4,y:.5,rx:.1,ry:.15,scale:1.8}];assert.equal(hitMask({x:.4,y:.5},masks),1);assert.equal(hitMask({x:.58,y:.5},masks),1);assert.equal(hitMask({x:.9,y:.5},masks),-1);});
test('project import restores edits and rejects unsafe or malformed image sources',()=>{
 const raw={kind:'veil-studio',version:1,image:'data:image/png;base64,AA==',name:'test',config:initialConfig(),masks:[{x:.5,y:.5,rx:.1,ry:.2,scale:1,style:'ghost'}],demo:false};
 assert.deepEqual(validateProject(raw),raw);
 for(const image of ['https://example.com/private.png','javascript:alert(1)','data:image/svg+xml;base64,AA=='])assert.throws(()=>validateProject({...raw,image}));
 assert.throws(()=>validateProject({...raw,masks:[{x:NaN,y:0,rx:.1,ry:.1,scale:1}]}));
 assert.throws(()=>validateProject({...raw,config:{...raw.config,scene:'invalid'}}));
});
test('landmark geometry handles empty and invalid sets without phantom masks',()=>{assert.equal(fromLandmarks([]),null);assert.equal(fromLandmarks([{x:NaN,y:NaN}]),null);const m=fromLandmarks([{x:.2,y:.1},{x:.6,y:.7}]);assert.ok(Math.abs(m.x-.4)<1e-8);assert.ok(Math.abs(m.y-.4)<1e-8);});
